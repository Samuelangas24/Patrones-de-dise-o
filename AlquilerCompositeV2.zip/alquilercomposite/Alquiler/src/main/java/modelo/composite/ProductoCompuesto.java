/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.composite;
import java.util.ArrayList;
import java.util.List;

public class ProductoCompuesto implements ProductoComponent {
    private String nombre;
    private List<ProductoComponent> componentes = new ArrayList<>();

    public ProductoCompuesto(String nombre) {
        this.nombre = nombre;
    }

    public void agregar(ProductoComponent componente) {
        componentes.add(componente);
    }

    public void eliminar(ProductoComponent componente) {
        componentes.remove(componente);
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public double getPrecio() {
        return componentes.stream().mapToDouble(ProductoComponent::getPrecio).sum();
    }

    @Override
    public int getCantidad() {
        return componentes.size();
    }

    @Override
    public double getSubtotal() {
        return componentes.stream().mapToDouble(ProductoComponent::getSubtotal).sum();
    }
}
