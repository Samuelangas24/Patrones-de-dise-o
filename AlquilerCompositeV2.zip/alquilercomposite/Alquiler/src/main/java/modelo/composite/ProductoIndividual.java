/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.composite;


public class ProductoIndividual implements ProductoComponent{
    private String nombre;
    private double precio;
    private int cantidad;

    public ProductoIndividual(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public double getPrecio() {
        return precio;
    }

    @Override
    public int getCantidad() {
        return cantidad;
    }

    @Override
    public double getSubtotal() {
        return precio * cantidad;
    }
}
