
package com.mycompany.alquiler;

/**
 *
 * @author Samuel
 */
public class Alquiler {
    //org.codehaus.mojo

    public static void main(String[] args) {
      /* configuracion.Conexion objetoConexion = new configuracion.Conexion();
     objetoConexion.estableceConexion();*/
       
       formulario.MenuPrincipal objetomenuPrincipal = new formulario.MenuPrincipal();
       objetomenuPrincipal.setVisible(true);
    
       
    } 
}
